<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class authentication_2 extends Model
{
    protected $table="authentication_2";
    public $timestamps=false;
}
