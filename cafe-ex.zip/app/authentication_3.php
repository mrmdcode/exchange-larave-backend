<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class authentication_3 extends Model
{
    protected $table="authentication_3";
    public $timestamps=false;
}
