<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class buy extends Model
{
    protected $table="buy";
    public $timestamps=false;
}
