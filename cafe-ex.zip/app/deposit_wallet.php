<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class deposit_wallet extends Model
{
    protected $table="deposit_wallet";
    public $timestamps=false;
}
