<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class authentication_1 extends Model
{
    protected $table="authentication_1";
    public $timestamps=false;

}
