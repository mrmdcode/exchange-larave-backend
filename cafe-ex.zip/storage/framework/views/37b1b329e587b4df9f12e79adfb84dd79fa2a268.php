<!--
    Buy_History
    Sell_History
    Sales_Under_Review_buy
    Sales_Under_Review_Sell
-->
<?php $__env->startSection('center'); ?>
    <div class="page-content-wrapper ">

        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h4 class="page-title m-0">   </h4>
                            </div>

                            <!-- end col -->
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end page-title-box -->
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">


                            <div class="row">
                                <div class="col-md-5">
                                    <div class="row">
                                            <table class="table table-bordered col-md-12" >

                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">زمان</th>
                                                <th scope="col">مقدار</th>
                                                <th scope="col">وضعیت</th>
                                            </tr>

                                            <tbody>
                                            <?php $__currentLoopData = $as_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($a=0+1); ?></th>
                                                    <td><?php echo e($as->Registration_time); ?></td>
                                                    <td><?php echo e($as->Amount); ?></td>
                                                    <?php if($as->Condition==0): ?>
                                                        <td class="bg-warning">
                                                             در حال پرداخت ....
                                                        </td>
                                                        <?php else: ?>
                                                        <td class="bg-success">
                                                            پرداخت شد .
                                                        </td>
                                                    <?php endif; ?>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>
                                    <br>
                                    <br>
                                    <div class="row">
                                        <table class="table col-md-12 table-bordered">
                                            <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">تایید</th>
                                                <th scope="col" style="margin-right: 20px;">وضیت</th>

                                            </tr>
                                            </thead>
                                            <?php if(Auth::user()->state_authentication==0 or Auth::user()->state_authentication==2): ?>
                                                <tbody>
                                                <tr >
                                                    <th scope="row">1</th>
                                                    <td>تایید هویت شخصی</td>
                                                    <th class="bg-warning">منتظر تایید...</th>
                                                </tr>
                                                <tr>
                                                    <th scope="row">2</th>
                                                    <td>تایید اطلاعات بانکی</td>
                                                    <th class="bg-warning">منتظر تایید...</th>
                                                </tr>
                                                <tr>
                                                    <th scope="row">3</th>
                                                    <td>تایید عکس ها </td>
                                                    <th class="bg-warning"> منتظر تایید...</th>
                                                </tr>

                                                </tbody>
                                                <?php else: ?>
                                                <tbody>
                                                <tr>
                                                    <th scope="row">1</th>
                                                    <td>تایید هویت شخصی</td>
                                                    <th class="bg-success">تایید شد.</th>
                                                </tr>
                                                <tr>
                                                    <th scope="row">2</th>
                                                    <td>تایید اطلاعات بانکی</td>
                                                    <th class="bg-success">تایید شد.</th>
                                                </tr>
                                                <tr>
                                                    <th scope="row">3</th>
                                                    <td>تایید عکس ها </td>
                                                    <th class="bg-success">تایید شد.</th>
                                                </tr>

                                                </tbody>
                                            <?php endif; ?>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-2"></div>
                                <div class="col-md-5">
                                    <div class="row ">
                                            <table class="table table-bordered col-md-12">
                                            <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">زمان</th>
                                                <th scope="col">مقدار</th>
                                                <th scope="col">وضعیت</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $as_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($a=0+1); ?></th>
                                                    <td><?php echo e($as->Registration_time); ?></td>
                                                    <td><?php echo e($as->Amount); ?></td>
                                                    <?php if($as->Condition==0): ?>
                                                        <td class="bg-warning">
                                                            در حال واریز ...
                                                        </td>
                                                    <?php else: ?>
                                                        <td class="bg-success">
                                                            واریز شد .
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br>

                                    <br>
                                    <div class="row">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('panel.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>