<?php $__env->startSection('center'); ?>
    <div class="page-content-wrapper ">

        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h4 class="page-title m-0">   </h4>
                            </div>

                            <!-- end col -->
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end page-title-box -->
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="row">
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <table class="table table-bordered">
                                    <tr class="text-center">
                                        <td>تایید سفارش</td>
                                        <td>پول پرداختی</td>
                                        <td>زمان</td>
                                        <td>اطلاعات بانکی</td>
                                        <td>QR</td>
                                        <td>#</td>
                                    </tr>
                                    <?php echo e($a=0); ?>

                                    <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td>
                                                <a href="/panel/admin/confirm-buy/<?php echo e($sell->Deposit_wallet_name); ?>/$/<?php echo e($sell->id); ?>">
                                                    <button class="btn-outline-success btn btn-block">پرداخت</button>
                                                </a>
                                            </td>

                                            <td><?php echo e($sell->Purchase_Price); ?></td>
                                            <td><?php echo e($sell->Registration_time); ?></td>
                                            <td>
                                                <ul class="fa-ul">
                                                    <li><?php echo e($sell->Account_Number); ?></li>
                                                    <li><?php echo e($sell->Card_Number); ?></li>
                                                    <li><?php echo e($sell->Shaba_Number); ?></li>
                                                    <li><?php echo e($sell->Cardholder_Name); ?></li>

                                                </ul>
                                            </td>
                                            <td><?php echo QrCode::size(195)->generate($sell->Deposit_wallet_SHARE);; ?></td>
                                            <td><?php echo e($a+1); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layout.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>