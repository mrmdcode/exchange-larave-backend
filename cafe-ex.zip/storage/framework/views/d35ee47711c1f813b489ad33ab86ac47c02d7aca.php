<?php $__env->startSection('center'); ?>
    <div class="page-content-wrapper ">

        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h4 class="page-title m-0">   </h4>
                            </div>

                            <!-- end col -->
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end page-title-box -->
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card m-b-30">
                        <div class="card-body">
                            <div class="row">
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>

                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-bordered col-md-12" >

                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">زمان</th>
                                            <th scope="col">مقدار</th>
                                            <th scope="col">وضعیت</th>
                                        </tr>

                                        <tbody>
                                        <?php $__currentLoopData = $buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($a=0+1); ?></th>
                                                <td><?php echo e($as->Registration_time); ?></td>
                                                <td><?php echo e($as->Amount); ?></td>
                                                <?php if($as->Condition==0): ?>
                                                    <td class="bg-warning">
                                                        در حال پرداخت ....
                                                    </td>
                                                <?php else: ?>
                                                    <td class="bg-success">
                                                        پرداخت شد .
                                                    </td>
                                                <?php endif; ?>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <table class="table table-bordered col-md-12" >

                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">زمان</th>
                                            <th scope="col">مقدار</th>
                                            <th scope="col">وضعیت</th>
                                        </tr>

                                        <tbody>
                                        <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $as): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($a=0+1); ?></th>
                                                <td><?php echo e($as->Registration_time); ?></td>
                                                <td><?php echo e($as->Amount); ?></td>
                                                <?php if($as->Condition==0): ?>
                                                    <td class="bg-warning">
                                                        در حال پرداخت ....
                                                    </td>
                                                <?php else: ?>
                                                    <td class="bg-success">
                                                        پرداخت شد .
                                                    </td>
                                                <?php endif; ?>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('panel.layout.app-2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>